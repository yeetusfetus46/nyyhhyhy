module.exports = {
  "serverURL": "ws://localhost:3000"
}
