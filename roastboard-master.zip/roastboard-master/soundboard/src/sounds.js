
module.exports = {
  "time_spent_worthless.mp3": {
    "text": "The way that you're spending your time right now is just so worthless",
    "source": "https://youtu.be/UcrYywntTso?t=2418"
  },
  "i_have_no_idea.mp3": {
    "text": "Honestly I have no fucking idea how you're 4.7k MMR",
    "source": "https://youtu.be/1i5ogmxO1BU?t=11"
  },
  "shit_playstyle.mp3": {
    "text": "You put a whole lotta words to that shit playstyle you developed",
    "source": "https://www.youtube.com/watch?v=1i5ogmxO1BU&t=1356s"
  },
  "its_not_worth_watching.mp3": {
    "text": "I don't think its worth watching the rest of this game honestly, because it's just mistake after mistake now",
    "source": "https://youtu.be/UOg1OPbJL28?t=2185"
  },
  "you_have_officially_made_a_huge_mistake.mp3": {
    "text": "You have officially made a huge mistake, okay..",
    "source": "https://www.youtube.com/watch?v=DiZzrBWhG4o&feature=youtu.be&t=117"
  },
  "huge_mistake.mp3": {
    "text": "HUUUUGEEE Mistake",
    "source": "https://www.youtube.com/watch?v=DiZzrBWhG4o&feature=youtu.be&t=1331"
  },
  "he_hasnt_done_shit.mp3": {
    "text": "What has he done in the meantime? He hasn't done shit, he's being buying in the store, he has full mana, hasn't been farming, could've farmed this, could've farmed this. So many things he could've done.",
    "source": "https://youtu.be/UOg1OPbJL28?t=2682"
  },
  "this_game_is_not_about_you.mp3": {
    "text": "This game is not about you",
    "source": "https://youtu.be/UOg1OPbJL28?t=2688"
  },
  "you_dont_understand.mp3": {
    "text": "It's probably because you're low MMR, you don't understand...",
    "source": "https://www.youtube.com/watch?v=DiZzrBWhG4o&feature=youtu.be&t=502"
  },
  "weak_players.mp3": {
    "text": "You guys are at 1k MMR because you are weak players, not because your allies are bad.",
    "source": "https://youtu.be/UOg1OPbJL28?t=2999"
  },
  "choosing_not_to_farm.mp3": {
    "text": "That's not playing support man. You're just playing a hero that chooses not to farm. That's it. That's all you're doing in this game.",
    "source": "https://www.youtube.com/watch?v=1mMmipyJH1g&feature=youtu.be&t=3959"
  },
  "alright_you_messed_up.mp3": {
    "text": "Alright, you super messed up there.",
    "source": "https://www.youtube.com/watch?v=DiZzrBWhG4o&feature=youtu.be&t=1925"
  },
  "its_like_league_of_legends.mp3": {
    "text": "It's like you're playing League of Legends now honestly..",
    "source": "https://www.youtube.com/watch?v=1mMmipyJH1g&feature=youtu.be&t=3903"
  },
  "infinitely_better.mp3": {
    "text": "That would've been infinitely better than how you have played this game.",
    "source": "https://www.youtube.com/watch?v=DiZzrBWhG4o&feature=youtu.be&t=1530"
  },
  "you_sunder_killed_yourself.mp3": {
    "text": "You actually just sunder killed yourself. I am actually really impressed. I am pretty blown away actually.",
    "source": "https://www.youtube.com/watch?v=DiZzrBWhG4o&feature=youtu.be&t=2720"
  },
  "attacking_the_wrong_guy.mp3": {
    "text": "And then you start attacking the wrong guy as well. You super messed up.",
    "source": "https://www.youtube.com/watch?v=DiZzrBWhG4o&feature=youtu.be&t=2742"
  },
  "right_click.mp3": {
    "text": "You can just right click, right click, right click... 6 last hits that you could've gotten right there. You can't do that shit man CMON",
    "source": "https://www.youtube.com/watch?v=1mMmipyJH1g&feature=youtu.be&t=1098"
  },
  "not_playing_dota_long.mp3": {
    "text": "You're basically just going to your lane slowly collecting farm and hoping that your opponents do it slower than you. You're not exerting lane pressure. You're basically not even playing Dota.",
    "source": "https://www.youtube.com/watch?v=1mMmipyJH1g&feature=youtu.be&t=1502"
  },
  "teammates_at_1kmmr.mp3": {
    "text": "Its not your teammates keeping you at 1K MMR. It's your shit farming patterns. Its your inefficient movement. Its your bad stacking. Its all of these things. You're not using your mana correctly. Your skillbuilds are aweful.",
    "source": "https://www.youtube.com/watch?v=UOg1OPbJL28&feature=youtu.be&t=2726"
  },
  "problem_with_1kmmr_players.mp3": {
    "text": "This is the problem with 1K MMR Players. They basically just show up and they stand around and eventually somebody dies.",
    "source": "https://www.youtube.com/watch?v=1mMmipyJH1g&feature=youtu.be&t=4048"
  },
  "oh_no_mistake.mp3": {
    "text": "OOOH NOOOOO OHHHH NOOOOO MISTAAAKKEEEE",
    "source": "https://www.youtube.com/watch?v=GQVVFQjBmiQ&feature=youtu.be&t=269"
  },
  "im_gonna_screw_you.mp3": {
    "text": "I'm gonna skewer you: you had a really shit early game!",
    "source": "https://www.youtube.com/watch?v=GQVVFQjBmiQ&feature=youtu.be&t=1916"
  },
  "coffin_tirade.mp3": {
    "text": "Tirade over Coffin",
    "source": "https://www.youtube.com/watch?v=GQVVFQjBmiQ&feature=youtu.be&t=2013"
  },
  "fuck_slacks.mp3": {
    "text": "Fuck slacks",
    "source": "https://youtu.be/Xb3073mNJ2Y?t=373"
  },
  "not_playing_dota.mp3": {
    "text": "You're basically not even playing Dota.",
    "source": "https://www.youtube.com/watch?v=1mMmipyJH1g&feature=youtu.be&t=1507"
  },
  "that_was_a_pretty_big_mistake.mp3": {
    "text": "That was a pretty big mistake",
    "source": "https://www.youtube.com/watch?v=DiZzrBWhG4o&feature=youtu.be&t=2742"
  }
}

